﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MVC_VS_nonMVC_yt
{
  public partial class Form1 : Form
  {
  
 
    public Form1()
    {
      InitializeComponent();

      //carico i dati nella View
      //NB: la View è legata al tipo di dato gestito dal Model 
      //    (è a conoscenza che si tratta di Auto)
      Auto[] datiAuto = Auto.getDatiAuto();

      for (int i = 0; i < datiAuto.Length; i++)
        View.Items.Add(
          "Auto: " + datiAuto[i].getDescrizione() + " - " +
          "Valore da nuova: " + Convert.ToString(datiAuto[i].getValoreNuova()) + " - " +
          "Valore  attuale: " + Convert.ToString(datiAuto[i].getValoreAttuale()));
    }

    public ListBox getView() { return View; }

    private void aggiornaBtn_Click(object sender, EventArgs e)
    {
      int posizioneAuto = Convert.ToInt32(posizioneTxt.Text);
      int nuoviSinistri = Convert.ToInt32(numeroSinistriTxt.Text);
      
      Auto.getDatiAuto()[ posizioneAuto ].setValoreAttualeCausaSinistri(nuoviSinistri);
    }

    private void View_SelectedIndexChanged(object sender, EventArgs e)
    {
      posizioneTxt.Text = View.SelectedIndex.ToString();
    }

    
  }
}

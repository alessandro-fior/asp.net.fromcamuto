﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MVC_VS_nonMVC_yt
{
  //sorgente dati (Model)
  class Auto
  {
    //Con un vettore statico rendo disponibile un elenco di auto
    //senza dover neppure comandare la creazione di nessun oggetto
    static Auto[] tabellaAuto = 
    { new Auto("Fiat Punto", 12000, 6800),
      new Auto("Maserati VIP", 280000, 240000),
      new Auto("Citroen xyZ", 23000, 15800) };
    
    public static Auto[] getDatiAuto() { return tabellaAuto; }
    //*********************************************************************************

//classe auto vera e propria
    string descrizione = ""; double valoreNuova = 0.0, valoreAttuale = 0.0;
    
    public Auto(string _descrizione, double _valoreNuova, 
                double _valoreAttuale)
    { descrizione = _descrizione; valoreNuova = _valoreNuova;
      valoreAttuale = _valoreAttuale;
    }

    public string getDescrizione() { return descrizione; }
    public double getValoreNuova() { return valoreNuova;  }
    public double getValoreAttuale() { return valoreAttuale; }

    public void setValoreAttualeCausaSinistri(int nuoviSinistri)
    {
      //algoritmo potenzialmente molto complesso per valutare il nuovo
      //valore attuale dell'auto ...
      //in questo caso tolgo una percentuale pari al (10*nuoviSinistri)%
      valoreAttuale = valoreAttuale * (1 - .1*nuoviSinistri); 

      //aggiorno in automatico il listbox sulla form (la view)
      //NB: il model in questo modo si lega alla View
      //    (è a conoscenza che si tratta di una ListBox)
      ListBox View = (Application.OpenForms[0] as Form1).getView();
      View.Items.Clear();

      for (int i = 0; i < tabellaAuto.Length; i++)
        View.Items.Add(
          "Auto: " + tabellaAuto[i].getDescrizione() + " - " +
          "Valore da nuova: " + Convert.ToString(tabellaAuto[i].getValoreNuova()) + " - " +
          "Valore  attuale: " + Convert.ToString(tabellaAuto[i].getValoreAttuale()));
      }
    }
  }


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MVC_VS_nonMVC_yt
{
  public partial class Form1 : Form
  {
  
 
    public Form1()
    {
      InitializeComponent();
    }

    public ComboBox getView() { return View; }

    private void aggiornaBtn_Click(object sender, EventArgs e)
    {
      int posizioneAuto = Convert.ToInt32(posizioneTxt.Text);
      int nuoviSinistri = Convert.ToInt32(numeroSinistriTxt.Text);
      Controller.aggiornaModel(posizioneAuto, nuoviSinistri);
    }

    private void View_SelectedIndexChanged(object sender, EventArgs e)
    {
      posizioneTxt.Text = View.SelectedIndex.ToString();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      Controller.aggiornaView();
    }

 

    
  }
}

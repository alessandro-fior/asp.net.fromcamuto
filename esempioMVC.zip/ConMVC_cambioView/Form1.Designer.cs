﻿namespace MVC_VS_nonMVC_yt
{
  partial class Form1
  {
    /// <summary>
    /// Variabile di progettazione necessaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Liberare le risorse in uso.
    /// </summary>
    /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Codice generato da Progettazione Windows Form

    /// <summary>
    /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
    /// il contenuto del metodo con l'editor di codice.
    /// </summary>
    private void InitializeComponent()
    {
      this.aggiornaBtn = new System.Windows.Forms.Button();
      this.posizioneTxt = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.numeroSinistriTxt = new System.Windows.Forms.TextBox();
      this.View = new System.Windows.Forms.ComboBox();
      this.SuspendLayout();
      // 
      // aggiornaBtn
      // 
      this.aggiornaBtn.Location = new System.Drawing.Point(118, 421);
      this.aggiornaBtn.Name = "aggiornaBtn";
      this.aggiornaBtn.Size = new System.Drawing.Size(75, 23);
      this.aggiornaBtn.TabIndex = 1;
      this.aggiornaBtn.Text = "AGGIORNA";
      this.aggiornaBtn.UseVisualStyleBackColor = true;
      this.aggiornaBtn.Click += new System.EventHandler(this.aggiornaBtn_Click);
      // 
      // posizioneTxt
      // 
      this.posizioneTxt.BackColor = System.Drawing.Color.Yellow;
      this.posizioneTxt.Location = new System.Drawing.Point(34, 372);
      this.posizioneTxt.Name = "posizioneTxt";
      this.posizioneTxt.ReadOnly = true;
      this.posizioneTxt.Size = new System.Drawing.Size(29, 20);
      this.posizioneTxt.TabIndex = 2;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(34, 349);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(146, 13);
      this.label1.TabIndex = 3;
      this.label1.Text = "Auto (SCEGLI DALLA LISTA)";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(33, 407);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(68, 13);
      this.label2.TabIndex = 5;
      this.label2.Text = "Nuovi Sinistri";
      // 
      // numeroSinistriTxt
      // 
      this.numeroSinistriTxt.Location = new System.Drawing.Point(34, 423);
      this.numeroSinistriTxt.Name = "numeroSinistriTxt";
      this.numeroSinistriTxt.Size = new System.Drawing.Size(56, 20);
      this.numeroSinistriTxt.TabIndex = 4;
      // 
      // View
      // 
      this.View.FormattingEnabled = true;
      this.View.Location = new System.Drawing.Point(37, 64);
      this.View.Name = "View";
      this.View.Size = new System.Drawing.Size(449, 21);
      this.View.TabIndex = 6;
      this.View.SelectedIndexChanged += new System.EventHandler(this.View_SelectedIndexChanged);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(558, 453);
      this.Controls.Add(this.View);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.numeroSinistriTxt);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.posizioneTxt);
      this.Controls.Add(this.aggiornaBtn);
      this.Name = "Form1";
      this.Text = "Form1";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button aggiornaBtn;
    private System.Windows.Forms.TextBox posizioneTxt;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox numeroSinistriTxt;
    private System.Windows.Forms.ComboBox View;
  }
}


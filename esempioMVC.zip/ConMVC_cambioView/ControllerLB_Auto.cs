﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MVC_VS_nonMVC_yt
{
  class Controller
  {
    static public void aggiornaView()
    {
      ComboBox View = (Application.OpenForms[0] as Form1).getView();
      Auto[] datiAuto = Auto.getDatiAuto();

      View.Items.Clear();

      for (int i = 0; i < datiAuto.Length; i++)
        View.Items.Add(
          "Auto: " + datiAuto[i].getDescrizione() + " - " +
          "Valore da nuova: " + Convert.ToString(datiAuto[i].getValoreNuova()) + " - " +
          "Valore  attuale: " + Convert.ToString(datiAuto[i].getValoreAttuale()));    
    }

    static public void aggiornaModel(int posizione, int valore)
    {
      Auto.getDatiAuto()[posizione].
        setValoreAttualeCausaSinistri(valore);

      aggiornaView();

    }

  }
}

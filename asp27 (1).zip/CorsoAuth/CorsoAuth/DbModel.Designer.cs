﻿// Generazione del codice predefinita abilitata per il modello 'c:\users\fabrizio\documents\visual studio 2013\Projects\CorsoAuth\CorsoAuth\DbModel.edmx'. 
// Per abilitare la generazione del codice legacy, modificare il valore della proprietà della finestra di progettazione 'Strategia di generazione del codice
// su 'Legacy ObjectContext'. Questa proprietà è disponibile nella finestra Proprietà quando il modello è
// aperto nella finestra di progettazione.

// La mancata generazione di classi contesto ed entità può essere dovuta al fatto che è stato creato un modello vuoto, ma
// non è ancora stata scelta la versione di Entity Framework da utilizzare. Per generare una classe contesto e classi entità
// per il modello, aprire il modello nella finestra di progettazione, fare clic con il pulsante destro del mouse nell'area di progettazione e
// selezionare 'Aggiorna modello da database...', 'Genera database da modello...' o 'Aggiungi elemento di generazione
// codice...'.
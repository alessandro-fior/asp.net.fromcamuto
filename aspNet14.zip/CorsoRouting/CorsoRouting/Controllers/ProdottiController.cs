﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CorsoRouting.Controllers
{
    public class ProdottiController : Controller
    {
        //
        // GET: /Prodotti/
        public ActionResult Dettaglio(int idP, string descrizione, DateTime dataVendita)
        {
            ViewBag.ProdID = idP;
            ViewBag.ProdDesc = descrizione;
            ViewBag.Data = dataVendita.ToShortDateString();
            return View();
        }

        [OutputCache(Duration = 10)]
        public string Orario()
        { return DateTime.Now.ToString("T"); }

        [Authorize]
        public ActionResult ListAccounts()
        {
            return View();
        }

        public ActionResult DettaglioTradizionale()
        {
            int idP = Convert.ToInt32(Request["idP"]);
            string ProdDesc = Request["descrizione"];
            DateTime DataDT = Convert.ToDateTime(Request["dataVendita"]);
            string Data = DataDT.ToShortDateString();

            
            return View();
        }

     }
    class Prodotto
    { }
}
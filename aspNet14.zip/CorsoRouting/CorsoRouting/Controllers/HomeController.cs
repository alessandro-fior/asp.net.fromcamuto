﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CorsoRouting.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            ViewBag.Messaggio = "Oggi è una bella giornata";
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Messaggio = "L'app più bella del mondo!!";
            return View();
        }

        public ActionResult About2()
        {
            ViewBag.Messaggio = "L'app ancora più bella del mondo!!";
            return View();
        }

        public ContentResult Benvenuto()
        {
            return Content("Benvenuto Utente!");
        }

   
	}

    
}
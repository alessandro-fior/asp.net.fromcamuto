﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CorsoCF.Models.ViewModels
{
    public class Benvenuto
    {
        public DateTime Data { get; set; }
        public int NumeroImpiegati { get; set; }
        public int NumeroAziende { get; set; }

    }
}